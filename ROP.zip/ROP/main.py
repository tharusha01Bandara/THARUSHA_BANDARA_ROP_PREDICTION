import os
import sys
import yaml
import warnings
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from src.utils.logger import setup_logger
from src.utils.visualization import (
    plot_signal_comparison,
    plot_predictions,
    plot_feature_importance,
    plot_model_comparison,
    plot_correlation_matrix
)
from src.data.data_loader import DataLoader
from src.preprocessing.sg_filter import SavitzkyGolayFilter
from src.features.feature_engineering import FeatureEngineer
from src.models.random_forest import RandomForestModel
from src.models.xgboost_model import XGBoostModel
from src.models.linear_regression import LinearRegressionModel
from src.evaluation.metrics import ModelEvaluator

warnings.filterwarnings('ignore')


def load_config(config_path="config/config.yaml"):
    with open(config_path, 'r') as f:
        return yaml.safe_load(f)


def create_output_directories(config):
    for key in ['models_dir', 'figures_dir', 'logs_dir']:
        os.makedirs(config['output'][key], exist_ok=True)


def main():
    """Main pipeline execution."""
    
    # Load configuration
    print("Loading configuration...")
    config = load_config()
    
    create_output_directories(config)
    logger = setup_logger(config['output']['logs_dir'])
    logger.info("="*70)
    logger.info("ROP PREDICTION MODEL")
    logger.info("="*70)
    
    try:
        # Load data
        logger.info("\nStep 1: Loading data...")
        data_loader = DataLoader(logger)
        df = data_loader.load_data(config['data']['raw_data_path'])
        
        # Apply Savitzky-Golay filter
        logger.info("\nStep 2: Applying filter...")
        sg_filter = SavitzkyGolayFilter(
            window_length=config['sg_filter']['window_length'],
            polyorder=config['sg_filter']['polyorder'],
            logger=logger
        )
        
        columns_to_filter = config['sg_filter']['columns_to_filter']
        df_filtered = sg_filter.replace_with_filtered(df, columns_to_filter)
        
        # Save example plot
        if columns_to_filter:
            plot_signal_comparison(
                df[columns_to_filter[0]].values[:500],
                df_filtered[columns_to_filter[0]].values[:500],
                columns_to_filter[0],
                save_path=os.path.join(config['output']['figures_dir'], 'sg_filter_example.png')
            )
        
        # Create features
        logger.info("\nStep 3: Creating features...")
        feature_engineer = FeatureEngineer(logger)
        df_features = feature_engineer.create_features(
            df_filtered,
            rolling_windows=config['features']['rolling_windows'],
            create_interactions=config['features']['create_interactions'],
            create_lag_features=config['features']['create_lag_features'],
            lag_steps=config['features']['lag_steps']
        )
        
        df_features.to_csv(config['data']['processed_data_path'], index=False)
        logger.info(f"Processed data saved")
        
        # Split data
        logger.info("\nStep 4: Splitting data...")
        X, y = data_loader.get_feature_target_split(df_features, target_column='ROP', exclude_columns=['well'])
        
        X_train, X_test, y_train, y_test = train_test_split(
            X, y,
            test_size=config['training']['test_size'],
            random_state=config['training']['random_state']
        )
        
        logger.info(f"Training set: {X_train.shape}, Test set: {X_test.shape}")
        
        plot_correlation_matrix(
            X_train.iloc[:, :20],
            save_path=os.path.join(config['output']['figures_dir'], 'correlation_matrix.png')
        )
        
        # Train models
        logger.info("\nStep 5: Training models...")
        
        models = {}
        results = {}
        
        # Train Random Forest
        logger.info("\nTraining Random Forest...")
        rf_config = config['models']['random_forest']
        rf_model = RandomForestModel(
            n_estimators=rf_config['n_estimators'],
            max_depth=rf_config['max_depth'],
            random_state=rf_config['random_state'],
            n_jobs=rf_config['n_jobs'],
            logger=logger
        )
        rf_model.fit(X_train.values, y_train.values)
        models['RandomForest'] = rf_model
        
        # Train XGBoost
        logger.info("\nTraining XGBoost...")
        xgb_config = config['models']['xgboost']
        xgb_model = XGBoostModel(
            n_estimators=xgb_config['n_estimators'],
            max_depth=xgb_config['max_depth'],
            learning_rate=xgb_config['learning_rate'],
            subsample=xgb_config['subsample'],
            colsample_bytree=xgb_config['colsample_bytree'],
            random_state=xgb_config['random_state'],
            n_jobs=xgb_config['n_jobs'],
            logger=logger
        )
        xgb_model.fit(X_train.values, y_train.values)
        models['XGBoost'] = xgb_model
        
        # Train Linear Regression
        logger.info("\nTraining Linear Regression...")
        lr_model = LinearRegressionModel(logger=logger)
        lr_model.fit(X_train.values, y_train.values)
        models['LinearRegression'] = lr_model
        
        # Evaluate models
        logger.info("\nStep 6: Evaluating models...")
        evaluator = ModelEvaluator(logger)
        
        for model_name, model in models.items():
            logger.info(f"\nEvaluating {model_name}...")
            
            y_pred = model.predict(X_test.values)
            metrics = evaluator.evaluate(y_test.values, y_pred, model_name)
            results[model_name] = metrics
            
            plot_predictions(
                y_test.values,
                y_pred,
                model_name,
                save_path=os.path.join(config['output']['figures_dir'], f'{model_name.lower()}_predictions.png')
            )
            
            feature_importance = model.get_feature_importance()
            if feature_importance is not None:
                plot_feature_importance(
                    feature_importance,
                    X.columns.tolist(),
                    model_name,
                    top_n=20,
                    save_path=os.path.join(config['output']['figures_dir'], f'{model_name.lower()}_feature_importance.png')
                )
            
            model.save_model(os.path.join(config['output']['models_dir'], f'{model_name.lower()}_model.pkl'))
        
        # Compare models
        logger.info("\nStep 7: Comparing models...")
        best_model_name = evaluator.compare_models(results)
        
        plot_model_comparison(
            results,
            save_path=os.path.join(config['output']['figures_dir'], 'model_comparison.png')
        )
        
        # Save results
        logger.info("\nSaving results...")
        results_df = pd.DataFrame(results).T
        results_df.to_csv(os.path.join(config['output']['models_dir'], 'model_results.csv'))
        
        logger.info("\n" + "="*70)
        logger.info("COMPLETED")
        logger.info("="*70)
        logger.info(f"\nBest Model: {best_model_name}")
        logger.info(f"R² Score: {results[best_model_name]['r2']:.4f}")
        logger.info(f"RMSE: {results[best_model_name]['rmse']:.4f}")
        
    except Exception as e:
        logger.error(f"\nError: {str(e)}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
