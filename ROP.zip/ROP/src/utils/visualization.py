"""Visualization utilities for ROP prediction model."""
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from typing import Dict, List, Optional
import os


def setup_plot_style():
    """Set up consistent plot styling."""
    plt.style.use('seaborn-v0_8-darkgrid')
    sns.set_palette("husl")


def plot_signal_comparison(
    original: np.ndarray,
    filtered: np.ndarray,
    column_name: str,
    save_path: Optional[str] = None
) -> None:
    """
    Plot original vs filtered signal.
    
    Args:
        original: Original signal
        filtered: Filtered signal
        column_name: Name of the column
        save_path: Path to save the figure
    """
    setup_plot_style()
    
    fig, ax = plt.subplots(figsize=(14, 6))
    
    indices = np.arange(len(original))
    ax.plot(indices, original, label='Original', alpha=0.6, linewidth=1)
    ax.plot(indices, filtered, label='SG Filtered', linewidth=2)
    
    ax.set_xlabel('Sample Index', fontsize=12)
    ax.set_ylabel(column_name, fontsize=12)
    ax.set_title(f'Savitzky-Golay Filter Applied to {column_name}', fontsize=14, fontweight='bold')
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
    else:
        plt.show()


def plot_predictions(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    model_name: str,
    save_path: Optional[str] = None
) -> None:
    """
    Plot actual vs predicted values.
    
    Args:
        y_true: True values
        y_pred: Predicted values
        model_name: Name of the model
        save_path: Path to save the figure
    """
    setup_plot_style()
    
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    # Scatter plot
    axes[0].scatter(y_true, y_pred, alpha=0.5, s=20)
    
    # Perfect prediction line
    min_val = min(y_true.min(), y_pred.min())
    max_val = max(y_true.max(), y_pred.max())
    axes[0].plot([min_val, max_val], [min_val, max_val], 'r--', linewidth=2, label='Perfect Prediction')
    
    axes[0].set_xlabel('Actual ROP', fontsize=12)
    axes[0].set_ylabel('Predicted ROP', fontsize=12)
    axes[0].set_title(f'{model_name}: Actual vs Predicted', fontsize=14, fontweight='bold')
    axes[0].legend(fontsize=10)
    axes[0].grid(True, alpha=0.3)
    
    # Residual plot
    residuals = y_true - y_pred
    axes[1].scatter(y_pred, residuals, alpha=0.5, s=20)
    axes[1].axhline(y=0, color='r', linestyle='--', linewidth=2)
    
    axes[1].set_xlabel('Predicted ROP', fontsize=12)
    axes[1].set_ylabel('Residuals', fontsize=12)
    axes[1].set_title(f'{model_name}: Residual Plot', fontsize=14, fontweight='bold')
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
    else:
        plt.show()


def plot_feature_importance(
    importance: np.ndarray,
    feature_names: List[str],
    model_name: str,
    top_n: int = 20,
    save_path: Optional[str] = None
) -> None:
    """
    Plot feature importance.
    
    Args:
        importance: Feature importance scores
        feature_names: Names of features
        model_name: Name of the model
        top_n: Number of top features to display
        save_path: Path to save the figure
    """
    setup_plot_style()
    
    # Create DataFrame and sort
    importance_df = pd.DataFrame({
        'feature': feature_names,
        'importance': importance
    }).sort_values('importance', ascending=False).head(top_n)
    
    fig, ax = plt.subplots(figsize=(10, 8))
    
    ax.barh(range(len(importance_df)), importance_df['importance'])
    ax.set_yticks(range(len(importance_df)))
    ax.set_yticklabels(importance_df['feature'])
    ax.invert_yaxis()
    
    ax.set_xlabel('Importance', fontsize=12)
    ax.set_title(f'{model_name}: Top {top_n} Feature Importance', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, axis='x')
    
    plt.tight_layout()
    
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
    else:
        plt.show()


def plot_model_comparison(
    results: Dict[str, Dict[str, float]],
    save_path: Optional[str] = None
) -> None:
    """
    Compare multiple models across metrics.
    
    Args:
        results: Dictionary with model names as keys and metric dictionaries as values
        save_path: Path to save the figure
    """
    setup_plot_style()
    
    # Create DataFrame
    df = pd.DataFrame(results).T
    
    # Plot
    fig, axes = plt.subplots(2, 2, figsize=(16, 12))
    axes = axes.ravel()
    
    metrics = df.columns
    for idx, metric in enumerate(metrics):
        if idx < len(axes):
            ax = axes[idx]
            df[metric].plot(kind='bar', ax=ax)
            ax.set_title(f'{metric.upper()}', fontsize=14, fontweight='bold')
            ax.set_xlabel('Model', fontsize=12)
            ax.set_ylabel(metric.upper(), fontsize=12)
            ax.grid(True, alpha=0.3, axis='y')
            ax.tick_params(axis='x', rotation=45)
    
    plt.tight_layout()
    
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
    else:
        plt.show()


def plot_correlation_matrix(
    data: pd.DataFrame,
    save_path: Optional[str] = None
) -> None:
    """
    Plot correlation matrix heatmap.
    
    Args:
        data: DataFrame with features
        save_path: Path to save the figure
    """
    setup_plot_style()
    
    # Calculate correlation matrix
    corr_matrix = data.corr()
    
    fig, ax = plt.subplots(figsize=(12, 10))
    
    sns.heatmap(
        corr_matrix,
        annot=True,
        fmt='.2f',
        cmap='coolwarm',
        center=0,
        square=True,
        linewidths=0.5,
        cbar_kws={"shrink": 0.8},
        ax=ax
    )
    
    ax.set_title('Feature Correlation Matrix', fontsize=14, fontweight='bold')
    
    plt.tight_layout()
    
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
    else:
        plt.show()
