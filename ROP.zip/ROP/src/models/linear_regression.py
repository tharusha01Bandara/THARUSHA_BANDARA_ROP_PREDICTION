import numpy as np
from sklearn.linear_model import LinearRegression
from .base_model import BaseModel


class LinearRegressionModel(BaseModel):
    
    def __init__(self, logger=None):
        super().__init__(logger)
        self.model = LinearRegression()
        self.logger.info("Linear Regression initialized")
    
    def fit(self, X_train, y_train):
        self.logger.info("Training Linear Regression...")
        self.model.fit(X_train, y_train)
        self.is_fitted = True
        self.logger.info("Training complete")
        return self
    
    def predict(self, X):
        if not self.is_fitted:
            raise ValueError("Model must be fitted first")
        return self.model.predict(X)
    
    def get_feature_importance(self):
        if not self.is_fitted:
            raise ValueError("Model must be fitted first")
        # Return coefficients as feature importance
        return np.abs(self.model.coef_)
