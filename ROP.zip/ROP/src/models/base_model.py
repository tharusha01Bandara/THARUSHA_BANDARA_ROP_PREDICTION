from abc import ABC, abstractmethod
import logging
import joblib
import os


class BaseModel(ABC):
    
    def __init__(self, logger=None):
        self.logger = logger or logging.getLogger(__name__)
        self.model = None
        self.is_fitted = False
    
    @abstractmethod
    def fit(self, X_train, y_train):
        pass
    
    @abstractmethod
    def predict(self, X):
        pass
    
    @abstractmethod
    def get_feature_importance(self):
        pass
    
    def save_model(self, filepath):
        if not self.is_fitted:
            raise ValueError("Model must be fitted before saving")
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        joblib.dump(self.model, filepath)
        self.logger.info(f"Model saved")
    
    def load_model(self, filepath):
        self.model = joblib.load(filepath)
        self.is_fitted = True
        self.logger.info(f"Model loaded")
