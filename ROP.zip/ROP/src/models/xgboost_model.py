import numpy as np
from xgboost import XGBRegressor
from .base_model import BaseModel


class XGBoostModel(BaseModel):
    
    def __init__(self, n_estimators=200, max_depth=8, learning_rate=0.05,
                 subsample=0.8, colsample_bytree=0.8, random_state=42, n_jobs=-1, logger=None):
        super().__init__(logger)
        
        self.model = XGBRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            subsample=subsample,
            colsample_bytree=colsample_bytree,
            random_state=random_state,
            n_jobs=n_jobs,
            verbosity=0
        )
        
        self.logger.info("XGBoost initialized")
    
    def fit(self, X_train, y_train):
        self.logger.info("Training XGBoost...")
        self.model.fit(X_train, y_train)
        self.is_fitted = True
        self.logger.info("Training complete")
        return self
    
    def predict(self, X):
        if not self.is_fitted:
            raise ValueError("Model must be fitted first")
        return self.model.predict(X)
    
    def get_feature_importance(self):
        if not self.is_fitted:
            raise ValueError("Model must be fitted first")
        return self.model.feature_importances_
