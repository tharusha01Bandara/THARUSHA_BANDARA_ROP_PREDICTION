import numpy as np
from sklearn.ensemble import RandomForestRegressor
from .base_model import BaseModel


class RandomForestModel(BaseModel):
    
    def __init__(self, n_estimators=200, max_depth=20, random_state=42, n_jobs=-1, logger=None):
        super().__init__(logger)
        
        self.model = RandomForestRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            random_state=random_state,
            n_jobs=n_jobs,
            verbose=0
        )
        
        self.logger.info(f"Random Forest initialized")
    
    def fit(self, X_train, y_train):
        self.logger.info("Training Random Forest...")
        self.model.fit(X_train, y_train)
        self.is_fitted = True
        self.logger.info("Training complete")
        return self
    
    def predict(self, X):
        if not self.is_fitted:
            raise ValueError("Model must be fitted first")
        return self.model.predict(X)
    
    def get_feature_importance(self):
        if not self.is_fitted:
            raise ValueError("Model must be fitted first")
        return self.model.feature_importances_
