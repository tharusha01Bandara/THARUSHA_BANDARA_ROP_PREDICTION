"""Feature engineering for ROP prediction."""
import pandas as pd
import numpy as np
from typing import List, Optional
import logging


class FeatureEngineer:
    """Create advanced features for ROP prediction."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Initialize FeatureEngineer.
        
        Args:
            logger: Logger instance
        """
        self.logger = logger or logging.getLogger(__name__)
        self.feature_names = []
    
    def create_features(
        self,
        df: pd.DataFrame,
        rolling_windows: List[int] = None,
        create_interactions: bool = True,
        create_lag_features: bool = True,
        lag_steps: List[int] = None
    ) -> pd.DataFrame:
        """
        Create comprehensive feature set.
        
        Args:
            df: Input DataFrame
            rolling_windows: List of window sizes for rolling features
            create_interactions: Whether to create interaction features
            create_lag_features: Whether to create lag features
            lag_steps: List of lag steps
            
        Returns:
            DataFrame with engineered features
        """
        df_features = df.copy()
        
        if rolling_windows is None:
            rolling_windows = [3, 5, 10, 20]
        if lag_steps is None:
            lag_steps = [1, 2, 3, 5]
        
        self.logger.info("Starting feature engineering...")
        
        # 1. Rolling statistics features
        df_features = self._create_rolling_features(df_features, rolling_windows)
        
        # 2. Lag features
        if create_lag_features:
            df_features = self._create_lag_features(df_features, lag_steps)
        
        # 3. Rate of change features
        df_features = self._create_rate_of_change_features(df_features)
        
        # 4. Domain-specific drilling features
        df_features = self._create_drilling_features(df_features)
        
        # 5. Interaction features
        if create_interactions:
            df_features = self._create_interaction_features(df_features)
        
        # Remove rows with NaN values created by rolling/lag operations
        initial_rows = len(df_features)
        df_features = df_features.dropna()
        removed_rows = initial_rows - len(df_features)
        
        if removed_rows > 0:
            self.logger.info(f"Removed {removed_rows} rows with NaN values")
        
        self.logger.info(f"Feature engineering complete. Final shape: {df_features.shape}")
        
        return df_features
    
    def _create_rolling_features(
        self,
        df: pd.DataFrame,
        windows: List[int]
    ) -> pd.DataFrame:
        """
        Create rolling window statistics features.
        
        Args:
            df: Input DataFrame
            windows: List of window sizes
            
        Returns:
            DataFrame with rolling features
        """
        numeric_cols = ['RPM', 'Flow', 'WOB', 'depth']
        
        for col in numeric_cols:
            if col not in df.columns:
                continue
            
            for window in windows:
                # Rolling mean
                df[f'{col}_rolling_mean_{window}'] = df[col].rolling(
                    window=window, min_periods=1
                ).mean()
                
                # Rolling std
                df[f'{col}_rolling_std_{window}'] = df[col].rolling(
                    window=window, min_periods=1
                ).std()
                
                # Rolling min/max
                df[f'{col}_rolling_min_{window}'] = df[col].rolling(
                    window=window, min_periods=1
                ).min()
                
                df[f'{col}_rolling_max_{window}'] = df[col].rolling(
                    window=window, min_periods=1
                ).max()
        
        self.logger.info(f"Created rolling features for windows: {windows}")
        return df
    
    def _create_lag_features(
        self,
        df: pd.DataFrame,
        lag_steps: List[int]
    ) -> pd.DataFrame:
        """
        Create lag features for time-series nature of drilling.
        
        Args:
            df: Input DataFrame
            lag_steps: List of lag steps
            
        Returns:
            DataFrame with lag features
        """
        lag_cols = ['RPM', 'Flow', 'WOB', 'ROP']
        
        for col in lag_cols:
            if col not in df.columns:
                continue
            
            for lag in lag_steps:
                df[f'{col}_lag_{lag}'] = df[col].shift(lag)
        
        self.logger.info(f"Created lag features for steps: {lag_steps}")
        return df
    
    def _create_rate_of_change_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create rate of change features.
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with rate of change features
        """
        change_cols = ['RPM', 'Flow', 'WOB', 'depth']
        
        for col in change_cols:
            if col not in df.columns:
                continue
            
            # First difference (rate of change)
            df[f'{col}_diff'] = df[col].diff()
            
            # Percentage change
            df[f'{col}_pct_change'] = df[col].pct_change().replace([np.inf, -np.inf], 0)
        
        self.logger.info("Created rate of change features")
        return df
    
    def _create_drilling_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create domain-specific drilling features.
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with drilling-specific features
        """
        # Mechanical Specific Energy (MSE) - indicator of drilling efficiency
        # MSE = (WOB/Area) + (2*pi*RPM*Torque)/(ROP*Area)
        # Simplified version without torque: proportional to WOB/ROP ratio
        if all(col in df.columns for col in ['WOB', 'ROP']):
            df['drilling_efficiency'] = df['WOB'] / (df['ROP'] + 1e-6)  # Avoid division by zero
        
        # Weight on Bit per RPM (drilling intensity)
        if all(col in df.columns for col in ['WOB', 'RPM']):
            df['WOB_per_RPM'] = df['WOB'] / (df['RPM'] + 1e-6)
        
        # Flow rate per RPM (hydraulics efficiency)
        if all(col in df.columns for col in ['Flow', 'RPM']):
            df['Flow_per_RPM'] = df['Flow'] / (df['RPM'] + 1e-6)
        
        # Combined drilling parameter (WOB * RPM)
        if all(col in df.columns for col in ['WOB', 'RPM']):
            df['WOB_RPM_product'] = df['WOB'] * df['RPM']
        
        # Flow efficiency with WOB
        if all(col in df.columns for col in ['Flow', 'WOB']):
            df['Flow_WOB_ratio'] = df['Flow'] / (df['WOB'] + 1e-6)
        
        # Normalized depth (0-1 range)
        if 'depth' in df.columns:
            df['depth_normalized'] = (df['depth'] - df['depth'].min()) / (
                df['depth'].max() - df['depth'].min() + 1e-6
            )
        
        self.logger.info("Created domain-specific drilling features")
        return df
    
    def _create_interaction_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create interaction features between key parameters.
        
        Args:
            df: Input DataFrame
            
        Returns:
            DataFrame with interaction features
        """
        # Key drilling parameters for interactions
        base_features = ['RPM', 'Flow', 'WOB']
        
        # Ensure all base features exist
        base_features = [f for f in base_features if f in df.columns]
        
        # Create polynomial interactions
        for i, feat1 in enumerate(base_features):
            for feat2 in base_features[i+1:]:
                # Multiplication
                df[f'{feat1}_x_{feat2}'] = df[feat1] * df[feat2]
                
                # Ratio (both directions)
                df[f'{feat1}_div_{feat2}'] = df[feat1] / (df[feat2] + 1e-6)
                df[f'{feat2}_div_{feat1}'] = df[feat2] / (df[feat1] + 1e-6)
        
        # Squared terms for non-linear relationships
        for feat in base_features:
            df[f'{feat}_squared'] = df[feat] ** 2
            df[f'{feat}_sqrt'] = np.sqrt(np.abs(df[feat]))
        
        self.logger.info("Created interaction features")
        return df
    
    def get_feature_names(self, df: pd.DataFrame, exclude_cols: List[str] = None) -> List[str]:
        """
        Get list of feature column names.
        
        Args:
            df: DataFrame with features
            exclude_cols: Columns to exclude
            
        Returns:
            List of feature names
        """
        if exclude_cols is None:
            exclude_cols = ['ROP', 'well']
        
        feature_names = [col for col in df.columns if col not in exclude_cols]
        return feature_names
