"""Savitzky-Golay filter implementation for signal preprocessing."""
import numpy as np
import pandas as pd
from scipy.signal import savgol_filter
from typing import List, Dict, Optional
import logging


class SavitzkyGolayFilter:
    """
    Apply Savitzky-Golay filter to smooth drilling data signals.
    
    The Savitzky-Golay filter is a digital filter that can be applied to a set
    of digital data points for smoothing while preserving important features
    of the distribution, such as relative maxima, minima, and width of peaks.
    """
    
    def __init__(
        self,
        window_length: int = 51,
        polyorder: int = 3,
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize Savitzky-Golay filter.
        
        Args:
            window_length: Length of the filter window (must be odd and >= polyorder + 2)
            polyorder: Order of polynomial used to fit the samples
            logger: Logger instance
            
        Raises:
            ValueError: If parameters are invalid
        """
        if window_length % 2 == 0:
            raise ValueError("window_length must be odd")
        if window_length < polyorder + 2:
            raise ValueError("window_length must be >= polyorder + 2")
        
        self.window_length = window_length
        self.polyorder = polyorder
        self.logger = logger or logging.getLogger(__name__)
        
        self.logger.info(
            f"SG Filter initialized: window_length={window_length}, polyorder={polyorder}"
        )
    
    def apply_filter(
        self,
        data: pd.DataFrame,
        columns: List[str]
    ) -> pd.DataFrame:
        """
        Apply Savitzky-Golay filter to specified columns.
        
        Args:
            data: Input DataFrame
            columns: List of column names to filter
            
        Returns:
            DataFrame with filtered columns (original data + filtered columns with _sg suffix)
        """
        df_filtered = data.copy()
        
        for col in columns:
            if col not in df_filtered.columns:
                self.logger.warning(f"Column '{col}' not found in data, skipping")
                continue
            
            try:
                # Apply SG filter
                filtered_signal = savgol_filter(
                    df_filtered[col].values,
                    window_length=self.window_length,
                    polyorder=self.polyorder,
                    mode='interp'  # Interpolate at boundaries
                )
                
                # Store filtered data with suffix
                filtered_col_name = f"{col}_sg"
                df_filtered[filtered_col_name] = filtered_signal
                
                # Calculate noise statistics
                noise = df_filtered[col].values - filtered_signal
                noise_std = np.std(noise)
                snr = self._calculate_snr(df_filtered[col].values, noise)
                
                self.logger.info(
                    f"Filtered '{col}': Noise STD={noise_std:.4f}, SNR={snr:.2f} dB"
                )
                
            except Exception as e:
                self.logger.error(f"Error filtering column '{col}': {str(e)}")
                raise
        
        return df_filtered
    
    def replace_with_filtered(
        self,
        data: pd.DataFrame,
        columns: List[str]
    ) -> pd.DataFrame:
        """
        Apply SG filter and replace original columns with filtered values.
        
        Args:
            data: Input DataFrame
            columns: List of column names to filter
            
        Returns:
            DataFrame with filtered values replacing original columns
        """
        df_filtered = data.copy()
        
        for col in columns:
            if col not in df_filtered.columns:
                self.logger.warning(f"Column '{col}' not found in data, skipping")
                continue
            
            try:
                # Apply SG filter and replace original
                df_filtered[col] = savgol_filter(
                    df_filtered[col].values,
                    window_length=self.window_length,
                    polyorder=self.polyorder,
                    mode='interp'
                )
                
                self.logger.info(f"Replaced '{col}' with filtered values")
                
            except Exception as e:
                self.logger.error(f"Error filtering column '{col}': {str(e)}")
                raise
        
        return df_filtered
    
    @staticmethod
    def _calculate_snr(signal: np.ndarray, noise: np.ndarray) -> float:
        """
        Calculate Signal-to-Noise Ratio in dB.
        
        Args:
            signal: Original signal
            noise: Noise component
            
        Returns:
            SNR in decibels
        """
        signal_power = np.mean(signal ** 2)
        noise_power = np.mean(noise ** 2)
        
        if noise_power == 0:
            return float('inf')
        
        snr = 10 * np.log10(signal_power / noise_power)
        return snr
    
    def get_filtering_stats(
        self,
        original: pd.DataFrame,
        filtered: pd.DataFrame,
        column: str
    ) -> Dict[str, float]:
        """
        Calculate statistics comparing original and filtered signals.
        
        Args:
            original: Original DataFrame
            filtered: Filtered DataFrame
            column: Column name to analyze
            
        Returns:
            Dictionary with statistics
        """
        orig_signal = original[column].values
        filt_signal = filtered[column].values if column in filtered else filtered[f"{column}_sg"].values
        
        noise = orig_signal - filt_signal
        
        stats = {
            'original_mean': np.mean(orig_signal),
            'filtered_mean': np.mean(filt_signal),
            'original_std': np.std(orig_signal),
            'filtered_std': np.std(filt_signal),
            'noise_std': np.std(noise),
            'snr_db': self._calculate_snr(orig_signal, noise),
            'correlation': np.corrcoef(orig_signal, filt_signal)[0, 1]
        }
        
        return stats
