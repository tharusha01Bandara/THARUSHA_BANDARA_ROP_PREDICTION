"""Data loader for ROP dataset."""
import pandas as pd
import numpy as np
from typing import Tuple
import logging


class DataLoader:
    """Load and validate ROP drilling data."""
    
    def __init__(self, logger: logging.Logger):
        """
        Initialize DataLoader.
        
        Args:
            logger: Logger instance
        """
        self.logger = logger
    
    def load_data(self, filepath: str) -> pd.DataFrame:
        """
        Load data from CSV file with validation.
        
        Args:
            filepath: Path to CSV file
            
        Returns:
            DataFrame with loaded data
            
        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If data validation fails
        """
        try:
            self.logger.info(f"Loading data from {filepath}")
            df = pd.read_csv(filepath)
            
            # Validate data
            self._validate_data(df)
            
            self.logger.info(f"Data loaded successfully. Shape: {df.shape}")
            self.logger.info(f"Columns: {df.columns.tolist()}")
            
            return df
            
        except FileNotFoundError:
            self.logger.error(f"File not found: {filepath}")
            raise
        except Exception as e:
            self.logger.error(f"Error loading data: {str(e)}")
            raise
    
    def _validate_data(self, df: pd.DataFrame) -> None:
        """
        Validate loaded data.
        
        Args:
            df: DataFrame to validate
            
        Raises:
            ValueError: If validation fails
        """
        # Check required columns
        required_columns = ['depth', 'RPM', 'Flow', 'WOB', 'ROP', 'well']
        missing_columns = set(required_columns) - set(df.columns)
        
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
        
        # Check for null values
        null_counts = df.isnull().sum()
        if null_counts.any():
            self.logger.warning(f"Null values found:\n{null_counts[null_counts > 0]}")
        
        # Check for negative values in features that should be positive
        positive_columns = ['RPM', 'Flow', 'WOB', 'ROP']
        for col in positive_columns:
            if (df[col] < 0).any():
                self.logger.warning(f"Negative values found in {col}")
        
        # Log data statistics
        self.logger.info(f"Data statistics:\n{df.describe()}")
        self.logger.info(f"Well distribution:\n{df['well'].value_counts()}")
    
    def get_feature_target_split(
        self,
        df: pd.DataFrame,
        target_column: str = 'ROP',
        exclude_columns: list = None
    ) -> Tuple[pd.DataFrame, pd.Series]:
        """
        Split data into features and target.
        
        Args:
            df: Input DataFrame
            target_column: Name of target column
            exclude_columns: Additional columns to exclude
            
        Returns:
            Tuple of (features DataFrame, target Series)
        """
        if exclude_columns is None:
            exclude_columns = ['well']
        
        # Exclude target and specified columns
        exclude_cols = [target_column] + exclude_columns
        feature_cols = [col for col in df.columns if col not in exclude_cols]
        
        X = df[feature_cols].copy()
        y = df[target_column].copy()
        
        self.logger.info(f"Features shape: {X.shape}")
        self.logger.info(f"Target shape: {y.shape}")
        self.logger.info(f"Feature columns: {feature_cols}")
        
        return X, y
