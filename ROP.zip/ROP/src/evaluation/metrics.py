"""Evaluation metrics for ROP prediction models."""
import numpy as np
from sklearn.metrics import (
    r2_score,
    mean_squared_error,
    mean_absolute_error,
    mean_absolute_percentage_error
)
from typing import Dict, Optional
import logging


class ModelEvaluator:
    """Evaluate model performance with multiple metrics."""
    
    def __init__(self, logger: Optional[logging.Logger] = None):
        """
        Initialize ModelEvaluator.
        
        Args:
            logger: Logger instance
        """
        self.logger = logger or logging.getLogger(__name__)
    
    def evaluate(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        model_name: str = "Model"
    ) -> Dict[str, float]:
        """
        Evaluate predictions with multiple metrics.
        
        Args:
            y_true: True values
            y_pred: Predicted values
            model_name: Name of the model being evaluated
            
        Returns:
            Dictionary with metric names and values
        """
        metrics = {}
        
        # R² Score (coefficient of determination)
        metrics['r2'] = r2_score(y_true, y_pred)
        
        # Root Mean Squared Error
        metrics['rmse'] = np.sqrt(mean_squared_error(y_true, y_pred))
        
        # Mean Absolute Error
        metrics['mae'] = mean_absolute_error(y_true, y_pred)
        
        # Mean Absolute Percentage Error
        # Handle zero values to avoid division by zero
        mask = y_true != 0
        if mask.any():
            metrics['mape'] = mean_absolute_percentage_error(y_true[mask], y_pred[mask]) * 100
        else:
            metrics['mape'] = float('inf')
        
        # Additional custom metrics
        metrics['max_error'] = np.max(np.abs(y_true - y_pred))
        metrics['std_residuals'] = np.std(y_true - y_pred)
        
        # Log metrics
        self.logger.info(f"\n{model_name} Evaluation Metrics:")
        self.logger.info(f"  R² Score: {metrics['r2']:.4f}")
        self.logger.info(f"  RMSE: {metrics['rmse']:.4f}")
        self.logger.info(f"  MAE: {metrics['mae']:.4f}")
        self.logger.info(f"  MAPE: {metrics['mape']:.2f}%")
        self.logger.info(f"  Max Error: {metrics['max_error']:.4f}")
        self.logger.info(f"  Std of Residuals: {metrics['std_residuals']:.4f}")
        
        return metrics
    
    def compare_models(
        self,
        results: Dict[str, Dict[str, float]]
    ) -> str:
        """
        Compare multiple models and determine the best one.
        
        Args:
            results: Dictionary with model names as keys and metrics as values
            
        Returns:
            Name of the best model (based on R² score)
        """
        self.logger.info("\n" + "="*70)
        self.logger.info("MODEL COMPARISON SUMMARY")
        self.logger.info("="*70)
        
        # Find best model based on R² score
        best_model = max(results.items(), key=lambda x: x[1]['r2'])
        best_model_name = best_model[0]
        
        # Print comparison table
        metrics_to_compare = ['r2', 'rmse', 'mae', 'mape']
        
        # Header
        header = f"{'Model':<20}"
        for metric in metrics_to_compare:
            header += f"{metric.upper():<15}"
        self.logger.info(header)
        self.logger.info("-"*70)
        
        # Each model's metrics
        for model_name, metrics in results.items():
            row = f"{model_name:<20}"
            for metric in metrics_to_compare:
                value = metrics.get(metric, 0)
                if metric == 'mape':
                    row += f"{value:<15.2f}"
                else:
                    row += f"{value:<15.4f}"
            
            if model_name == best_model_name:
                row += " <- BEST"
            
            self.logger.info(row)
        
        self.logger.info("="*70)
        self.logger.info(f"Best Model: {best_model_name} (R² = {best_model[1]['r2']:.4f})")
        self.logger.info("="*70)
        
        return best_model_name
    
    def calculate_confidence_intervals(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        confidence: float = 0.95
    ) -> Dict[str, float]:
        """
        Calculate confidence intervals for predictions.
        
        Args:
            y_true: True values
            y_pred: Predicted values
            confidence: Confidence level (default: 0.95)
            
        Returns:
            Dictionary with confidence interval bounds
        """
        residuals = y_true - y_pred
        std_residuals = np.std(residuals)
        
        # Z-score for confidence level
        from scipy import stats
        z_score = stats.norm.ppf((1 + confidence) / 2)
        
        margin_of_error = z_score * std_residuals
        
        return {
            'lower_bound': -margin_of_error,
            'upper_bound': margin_of_error,
            'confidence_level': confidence
        }
