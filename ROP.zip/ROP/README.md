

Machine learning project to predict drilling Rate of Penetration (ROP) using sensor data.

## Quick Start

Install dependencies:
```bash
pip install -r requirements.txt
```

Run the pipeline:
```bash
python main.py
```


